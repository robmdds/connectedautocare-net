
# TPA Platform – Helcim Payments (Auto-Issuance on Webhook)

This starter is configured to use **Helcim** as the payment processor and now includes **auto-policy issuance**
upon verified Helcim payment webhooks (stubbed).

## Flow
1) Frontend calls `POST /payments/intent` to create a (mock) Helcim intent.
2) When Helcim sends a `payment.succeeded` webhook to `POST /webhooks/helcim`:
   - The API (stub) "verifies" signature (TODO) and calls `PoliciesService.issueForPayment(payload)`.
   - A mock `policyNumber` is generated and a JSON receipt is written to `storage/receipts/`.
   - An issued policy JSON is written to `storage/policies/`.

> Replace the stubbed verification and Helcim calls with real API + signature checks in Softgen's generation step.

## Env
- `PAYMENTS_PROVIDER=helcim`
- `HELCIM_API_TOKEN`, `HELCIM_ACCOUNT_ID`, `HELCIM_WEBHOOK_SECRET`

## Endpoints
- `POST /payments/intent` — returns a mock `clientSecret` to unblock the flow
- `POST /webhooks/helcim` — handles payment webhook and triggers issuance

Artifacts written to `storage/` so you can see results locally.
